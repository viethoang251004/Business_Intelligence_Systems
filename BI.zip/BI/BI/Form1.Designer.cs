﻿namespace BI
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button4 = new Button();
            button5 = new Button();
            button1 = new Button();
            label1 = new Label();
            dataGridView1 = new DataGridView();
            button3 = new Button();
            button6 = new Button();
            button2 = new Button();
            button8 = new Button();
            labelFilePath = new Label();
            button9 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // button4
            // 
            button4.Location = new Point(366, 704);
            button4.Margin = new Padding(5, 7, 5, 7);
            button4.Name = "button4";
            button4.Size = new Size(0, 0);
            button4.TabIndex = 24;
            button4.Text = "button4";
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Location = new Point(484, 920);
            button5.Margin = new Padding(5, 7, 5, 7);
            button5.Name = "button5";
            button5.Size = new Size(0, 0);
            button5.TabIndex = 25;
            button5.Text = "button5";
            button5.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.BackColor = Color.AliceBlue;
            button1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold);
            button1.Location = new Point(89, 276);
            button1.Margin = new Padding(5, 7, 5, 7);
            button1.Name = "button1";
            button1.Size = new Size(221, 69);
            button1.TabIndex = 60;
            button1.Text = "Chọn tệp";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click_1;
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top;
            label1.AutoEllipsis = true;
            label1.Font = new Font("Segoe UI", 35F, FontStyle.Bold);
            label1.ForeColor = Color.White;
            label1.Location = new Point(658, 69);
            label1.Margin = new Padding(5, 0, 5, 0);
            label1.Name = "label1";
            label1.Size = new Size(635, 136);
            label1.TabIndex = 57;
            label1.Text = "Nhập dữ liệu";
            label1.Click += label1_Click_1;
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.None;
            dataGridView1.BackgroundColor = SystemColors.AppWorkspace;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(81, 395);
            dataGridView1.Margin = new Padding(5, 7, 5, 7);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.ReadOnly = true;
            dataGridView1.RowHeadersWidth = 82;
            dataGridView1.Size = new Size(1784, 843);
            dataGridView1.TabIndex = 63;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // button3
            // 
            button3.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            button3.BackColor = Color.SkyBlue;
            button3.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            button3.Location = new Point(1290, 276);
            button3.Margin = new Padding(5, 7, 5, 7);
            button3.Name = "button3";
            button3.Size = new Size(292, 69);
            button3.TabIndex = 64;
            button3.Text = "Làm sạch data cơ bản";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button6
            // 
            button6.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            button6.BackColor = Color.Green;
            button6.Font = new Font("Segoe UI Semibold", 10F, FontStyle.Bold);
            button6.ForeColor = Color.White;
            button6.Location = new Point(1607, 276);
            button6.Margin = new Padding(5, 7, 5, 7);
            button6.Name = "button6";
            button6.Size = new Size(258, 69);
            button6.TabIndex = 65;
            button6.Text = "Lưu dữ liệu về máy";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button2
            // 
            button2.Anchor = AnchorStyles.Bottom;
            button2.BackColor = SystemColors.HighlightText;
            button2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            button2.Location = new Point(1386, 1772);
            button2.Margin = new Padding(5);
            button2.Name = "button2";
            button2.Size = new Size(455, 94);
            button2.TabIndex = 66;
            button2.Text = "Xử lí dữ liệu";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click_1;
            // 
            // button8
            // 
            button8.Anchor = AnchorStyles.Bottom;
            button8.BackColor = SystemColors.HighlightText;
            button8.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            button8.Location = new Point(255, 1772);
            button8.Margin = new Padding(5);
            button8.Name = "button8";
            button8.Size = new Size(455, 94);
            button8.TabIndex = 70;
            button8.Text = "Dự báo và Trực quan";
            button8.UseVisualStyleBackColor = false;
            // 
            // labelFilePath
            // 
            labelFilePath.AutoSize = true;
            labelFilePath.Font = new Font("Segoe UI Semibold", 10.875F, FontStyle.Bold, GraphicsUnit.Point, 163);
            labelFilePath.ForeColor = Color.White;
            labelFilePath.Location = new Point(336, 291);
            labelFilePath.Margin = new Padding(5, 0, 5, 0);
            labelFilePath.Name = "labelFilePath";
            labelFilePath.Size = new Size(359, 40);
            labelFilePath.TabIndex = 58;
            labelFilePath.Text = "Không tệp nào được chọn";
            labelFilePath.Click += labelFilePath_Click;
            // 
            // button9
            // 
            button9.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            button9.BackColor = SystemColors.HighlightText;
            button9.Font = new Font("Segoe UI Semibold", 11F);
            button9.Location = new Point(1676, 1250);
            button9.Margin = new Padding(5);
            button9.Name = "button9";
            button9.Size = new Size(167, 71);
            button9.TabIndex = 71;
            button9.Text = "Tiếp tục";
            button9.UseVisualStyleBackColor = true;
            button9.Click += button9_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(13F, 32F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(64, 64, 64);
            ClientSize = new Size(1947, 1344);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button2);
            Controls.Add(button6);
            Controls.Add(button3);
            Controls.Add(dataGridView1);
            Controls.Add(button1);
            Controls.Add(labelFilePath);
            Controls.Add(label1);
            Controls.Add(button5);
            Controls.Add(button4);
            FormBorderStyle = FormBorderStyle.FixedSingle;
            Margin = new Padding(5, 7, 5, 7);
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button4;
        private Button button5;
        private Button button1;
        private Label label1;
        private DataGridView dataGridView1;
        private Button button3;
        private Button button6;
        private Button button2;
        private Button button8;
        private Label labelFilePath;
        private Button button9;
    }
}
