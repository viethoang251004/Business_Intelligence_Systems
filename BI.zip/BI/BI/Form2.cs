﻿using System.Data;
using System.Windows.Forms;

namespace BI
{
    public partial class Form2 : Form
    {
        private DataTable dataForAnalysis;
        public Form2(DataTable data)
        {
            InitializeComponent();
            dataForAnalysis = data;
            dataGridView1.DataSource = data.Copy();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
        }


        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView4_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView10_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
        private void Form2_Load(object sender, EventArgs e)
        {
            foreach (DataColumn column in dataForAnalysis.Columns)
            {
                Cate.Items.Add(column.ColumnName);
                Time.Items.Add(column.ColumnName);
                Price.Items.Add(column.ColumnName);
                Quantity.Items.Add(column.ColumnName);
                Revenue.Items.Add(column.ColumnName);
                Profit.Items.Add(column.ColumnName);
            }

            Cate.ItemCheck += checkedListBox2_ItemCheck;
            Time.ItemCheck += checkedListBox3_ItemCheck;
            Price.ItemCheck += checkedListBox4_ItemCheck;
            Quantity.ItemCheck += checkedListBox5_ItemCheck;
            Revenue.ItemCheck += checkedListBox6_ItemCheck;
            Profit.ItemCheck += checkedListBox7_ItemCheck;
        }
        private void checkedListBox2_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            // Khi một mục được chọn, bỏ chọn các mục khác
            if (e.NewValue == CheckState.Checked)
            {
                for (int i = 0; i < Cate.Items.Count; i++)
                {
                    if (i != e.Index)
                    {
                        Cate.SetItemChecked(i, false);
                    }
                }
            }
        }
        private void checkedListBox3_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            // Khi một mục được chọn, bỏ chọn các mục khác
            if (e.NewValue == CheckState.Checked)
            {
                for (int i = 0; i < Time.Items.Count; i++)
                {
                    if (i != e.Index)
                    {
                        Time.SetItemChecked(i, false);
                    }
                }
            }
        }
        private void checkedListBox4_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            // Khi một mục được chọn, bỏ chọn các mục khác
            if (e.NewValue == CheckState.Checked)
            {
                for (int i = 0; i < Price.Items.Count; i++)
                {
                    if (i != e.Index)
                    {
                        Price.SetItemChecked(i, false);
                    }
                }
            }
        }
        private void checkedListBox5_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            // Khi một mục được chọn, bỏ chọn các mục khác
            if (e.NewValue == CheckState.Checked)
            {
                for (int i = 0; i < Quantity.Items.Count; i++)
                {
                    if (i != e.Index)
                    {
                        Quantity.SetItemChecked(i, false);
                    }
                }
            }
        }
        private void checkedListBox6_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            // Khi một mục được chọn, bỏ chọn các mục khác
            if (e.NewValue == CheckState.Checked)
            {
                for (int i = 0; i < Revenue.Items.Count; i++)
                {
                    if (i != e.Index)
                    {
                        Revenue.SetItemChecked(i, false);
                    }
                }
            }
        }
        private void checkedListBox7_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            // Khi một mục được chọn, bỏ chọn các mục khác
            if (e.NewValue == CheckState.Checked)
            {
                for (int i = 0; i < Profit.Items.Count; i++)
                {
                    if (i != e.Index)
                    {
                        Profit.SetItemChecked(i, false);
                    }
                }
            }
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }

        private void checkedListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void checkedListBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void checkedListBox3_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void Cate_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Price_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Quantity_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Revenue_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Profit_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            if (Time.CheckedItems.Count == 0)
            {
                MessageBox.Show("Bắt buộc phải có dữ liệu của Time", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Kiểm tra nếu không có mục nào được chọn trong CheckedListBox Revenue
            if (Revenue.CheckedItems.Count == 0)
            {
                MessageBox.Show("Bắt buộc phải có dữ liệu của Revenue", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Tạo một DataTable mới để chứa các cột đã chọn với tên cột được thay đổi
            DataTable filteredData = new DataTable();

            // Thêm các cột đã chọn từ mỗi CheckedListBox với tên cột được đổi
            AddCheckedColumnWithNewName(Cate, "Cate", filteredData);
            AddCheckedColumnWithNewName(Time, "Time", filteredData);
            AddCheckedColumnWithNewName(Price, "Price", filteredData);
            AddCheckedColumnWithNewName(Quantity, "Quantity", filteredData);
            AddCheckedColumnWithNewName(Revenue, "Revenue", filteredData);
            AddCheckedColumnWithNewName(Profit, "Profit", filteredData);

            // Thêm dữ liệu từ DataTable gốc vào DataTable đã lọc với tên cột mới
            foreach (DataRow row in dataForAnalysis.Rows)
            {
                DataRow newRow = filteredData.NewRow();

                // Sao chép dữ liệu từ các cột gốc sang cột mới trong DataTable đã lọc
                foreach (DataColumn column in filteredData.Columns)
                {
                    string originalColumnName = GetOriginalColumnName(column.ColumnName);
                    if (dataForAnalysis.Columns.Contains(originalColumnName))
                    {
                        newRow[column.ColumnName] = row[originalColumnName];
                    }
                }
                filteredData.Rows.Add(newRow);
            }

            // Cập nhật DataGridView để hiển thị DataTable đã lọc với tên cột mới
            dataGridView1.DataSource = filteredData;
        }
        private string GetOriginalColumnName(string newColumnName)
        {
            if (newColumnName == "Cate") return Cate.CheckedItems.Count > 0 ? Cate.CheckedItems[0].ToString() : "Cate";
            if (newColumnName == "Time") return Time.CheckedItems.Count > 0 ? Time.CheckedItems[0].ToString() : "Time";
            if (newColumnName == "Price") return Price.CheckedItems.Count > 0 ? Price.CheckedItems[0].ToString() : "Price";
            if (newColumnName == "Quantity") return Quantity.CheckedItems.Count > 0 ? Quantity.CheckedItems[0].ToString() : "Quantity";
            if (newColumnName == "Revenue") return Revenue.CheckedItems.Count > 0 ? Revenue.CheckedItems[0].ToString() : "Revenue";
            if (newColumnName == "Profit") return Profit.CheckedItems.Count > 0 ? Profit.CheckedItems[0].ToString() : "Profit";
            return newColumnName; // Trả về tên cột mới nếu không tìm thấy
        }


        // Hàm hỗ trợ để thêm các cột đã chọn từ một CheckedListBox vào danh sách
        private void AddCheckedColumnWithNewName(CheckedListBox checkedListBox, string newColumnName, DataTable dataTable)
        {
            if (checkedListBox.CheckedItems.Count > 0)
            {
                // Chỉ lấy mục đầu tiên được chọn vì chỉ cho phép chọn một mục
                string originalColumnName = checkedListBox.CheckedItems[0].ToString();
                if (dataForAnalysis.Columns.Contains(originalColumnName))
                {
                    dataTable.Columns.Add(newColumnName, dataForAnalysis.Columns[originalColumnName].DataType);
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "CSV files (*.csv)|*.csv";
                saveFileDialog.Title = "Lưu dữ liệu thành file CSV";

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    using (StreamWriter writer = new StreamWriter(saveFileDialog.FileName))
                    {
                        // Ghi dòng tiêu đề (tên cột)
                        for (int i = 0; i < dataGridView1.Columns.Count; i++)
                        {
                            writer.Write($"\"{dataGridView1.Columns[i].HeaderText}\"");
                            if (i < dataGridView1.Columns.Count - 1)
                                writer.Write(",");
                        }
                        writer.WriteLine();

                        // Ghi dữ liệu từng hàng
                        foreach (DataGridViewRow row in dataGridView1.Rows)
                        {
                            if (!row.IsNewRow)
                            {
                                for (int i = 0; i < dataGridView1.Columns.Count; i++)
                                {
                                    // Thêm dấu ngoặc kép xung quanh nội dung ô
                                    var cellValue = row.Cells[i].Value?.ToString().Replace("\"", "\"\""); // Xử lý dấu ngoặc kép trong nội dung
                                    writer.Write($"\"{cellValue}\"");

                                    if (i < dataGridView1.Columns.Count - 1)
                                        writer.Write(",");
                                }
                                writer.WriteLine();
                            }
                        }
                    }
                    MessageBox.Show("Dữ liệu đã được lưu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void button7_Click_1(object sender, EventArgs e)
        {
            DataTable filteredData = new DataTable();

            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                filteredData.Columns.Add(column.HeaderText, column.ValueType);
            }

            // Thêm các hàng từ dataGridView1 vào filteredData
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (!row.IsNewRow)
                {
                    DataRow newRow = filteredData.NewRow();
                    foreach (DataGridViewCell cell in row.Cells)
                    {
                        newRow[cell.ColumnIndex] = cell.Value;
                    }
                    filteredData.Rows.Add(newRow);
                }
            }

            Form3 form3 = new Form3(filteredData);
            form3.Show();
            this.Hide();
        }
    }
}