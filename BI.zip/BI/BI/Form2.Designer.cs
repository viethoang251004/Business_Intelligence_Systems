﻿namespace BI
{
    partial class Form2
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            ID = new Label();
            button4 = new Button();
            button5 = new Button();
            dataGridView1 = new DataGridView();
            button2 = new Button();
            button1 = new Button();
            label2 = new Label();
            Cate = new CheckedListBox();
            label3 = new Label();
            Time = new CheckedListBox();
            label4 = new Label();
            Price = new CheckedListBox();
            Quantity = new CheckedListBox();
            label6 = new Label();
            Revenue = new CheckedListBox();
            Profit = new CheckedListBox();
            label8 = new Label();
            label7 = new Label();
            button3 = new Button();
            button6 = new Button();
            button7 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.Anchor = AnchorStyles.Top;
            label1.AutoEllipsis = true;
            label1.Font = new Font("Segoe UI", 35F, FontStyle.Bold);
            label1.ForeColor = Color.MidnightBlue;
            label1.Location = new Point(377, 9);
            label1.Name = "label1";
            label1.Size = new Size(457, 61);
            label1.TabIndex = 4;
            label1.Text = "Phân tách dữ liệu";
            label1.Click += label1_Click;
            // 
            // ID
            // 
            ID.Anchor = AnchorStyles.None;
            ID.AutoSize = true;
            ID.BackColor = Color.Transparent;
            ID.Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold);
            ID.ForeColor = Color.Red;
            ID.Location = new Point(99, 166);
            ID.Name = "ID";
            ID.Size = new Size(443, 15);
            ID.TabIndex = 14;
            ID.Text = "*Vui lòng chọn đúng cột thông tin (càng nhiều thông tin, sai số dự báo càng thấp)\r\n";
            ID.Click += label3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(167, 184);
            button4.Name = "button4";
            button4.Size = new Size(0, 0);
            button4.TabIndex = 24;
            button4.Text = "button4";
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Location = new Point(231, 285);
            button5.Name = "button5";
            button5.Size = new Size(0, 0);
            button5.TabIndex = 25;
            button5.Text = "button5";
            button5.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.None;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(92, 188);
            dataGridView1.Margin = new Padding(3, 2, 3, 2);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 82;
            dataGridView1.Size = new Size(1025, 483);
            dataGridView1.TabIndex = 54;
            // 
            // button2
            // 
            button2.Anchor = AnchorStyles.Bottom;
            button2.BackColor = Color.FromArgb(64, 64, 64);
            button2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            button2.ForeColor = Color.White;
            button2.Location = new Point(827, 924);
            button2.Margin = new Padding(3, 2, 3, 2);
            button2.Name = "button2";
            button2.Size = new Size(245, 44);
            button2.TabIndex = 67;
            button2.Text = "Xử lí dữ liệu";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click_1;
            // 
            // button1
            // 
            button1.Anchor = AnchorStyles.Bottom;
            button1.BackColor = Color.FromArgb(64, 64, 64);
            button1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            button1.ForeColor = Color.White;
            button1.Location = new Point(522, 924);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(245, 44);
            button1.TabIndex = 68;
            button1.Text = "Chọn dữ liệu";
            button1.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.Anchor = AnchorStyles.None;
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label2.Location = new Point(746, 107);
            label2.Name = "label2";
            label2.Size = new Size(82, 20);
            label2.TabIndex = 70;
            label2.Text = "Doanh thu";
            label2.Click += label2_Click;
            // 
            // Cate
            // 
            Cate.Anchor = AnchorStyles.None;
            Cate.BackColor = Color.White;
            Cate.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            Cate.FormattingEnabled = true;
            Cate.Location = new Point(99, 135);
            Cate.Margin = new Padding(3, 2, 3, 2);
            Cate.Name = "Cate";
            Cate.Size = new Size(122, 4);
            Cate.TabIndex = 71;
            Cate.SelectedIndexChanged += Cate_SelectedIndexChanged;
            // 
            // label3
            // 
            label3.Anchor = AnchorStyles.None;
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label3.Location = new Point(254, 91);
            label3.Name = "label3";
            label3.Size = new Size(78, 40);
            label3.TabIndex = 72;
            label3.Text = "Thời gian \r\nmua hàng";
            // 
            // Time
            // 
            Time.Anchor = AnchorStyles.None;
            Time.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            Time.ForeColor = Color.Black;
            Time.FormattingEnabled = true;
            Time.Location = new Point(254, 135);
            Time.Margin = new Padding(3, 2, 3, 2);
            Time.Name = "Time";
            Time.Size = new Size(122, 4);
            Time.TabIndex = 73;
            Time.SelectedIndexChanged += checkedListBox3_SelectedIndexChanged;
            // 
            // label4
            // 
            label4.Anchor = AnchorStyles.None;
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label4.Location = new Point(99, 91);
            label4.Name = "label4";
            label4.Size = new Size(122, 40);
            label4.TabIndex = 74;
            label4.Text = "Nhóm sản phẩm\r\n(nếu có)\r\n";
            label4.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Price
            // 
            Price.Anchor = AnchorStyles.None;
            Price.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            Price.FormattingEnabled = true;
            Price.Location = new Point(410, 135);
            Price.Margin = new Padding(3, 2, 3, 2);
            Price.Name = "Price";
            Price.Size = new Size(121, 4);
            Price.TabIndex = 75;
            Price.SelectedIndexChanged += Price_SelectedIndexChanged;
            // 
            // Quantity
            // 
            Quantity.Anchor = AnchorStyles.None;
            Quantity.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            Quantity.FormattingEnabled = true;
            Quantity.Location = new Point(590, 137);
            Quantity.Margin = new Padding(3, 2, 3, 2);
            Quantity.Name = "Quantity";
            Quantity.Size = new Size(121, 4);
            Quantity.TabIndex = 77;
            Quantity.SelectedIndexChanged += Quantity_SelectedIndexChanged;
            // 
            // label6
            // 
            label6.Anchor = AnchorStyles.None;
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label6.Location = new Point(590, 91);
            label6.Name = "label6";
            label6.Size = new Size(70, 40);
            label6.TabIndex = 78;
            label6.Text = "Số lượng\r\n(nếu có)\r\n";
            label6.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Revenue
            // 
            Revenue.Anchor = AnchorStyles.None;
            Revenue.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            Revenue.FormattingEnabled = true;
            Revenue.Location = new Point(746, 137);
            Revenue.Margin = new Padding(3, 2, 3, 2);
            Revenue.Name = "Revenue";
            Revenue.Size = new Size(121, 4);
            Revenue.TabIndex = 79;
            Revenue.SelectedIndexChanged += Revenue_SelectedIndexChanged;
            // 
            // Profit
            // 
            Profit.Anchor = AnchorStyles.None;
            Profit.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            Profit.FormattingEnabled = true;
            Profit.Location = new Point(893, 135);
            Profit.Margin = new Padding(3, 2, 3, 2);
            Profit.Name = "Profit";
            Profit.Size = new Size(121, 4);
            Profit.TabIndex = 81;
            Profit.SelectedIndexChanged += Profit_SelectedIndexChanged;
            // 
            // label8
            // 
            label8.Anchor = AnchorStyles.None;
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label8.Location = new Point(410, 91);
            label8.Name = "label8";
            label8.Size = new Size(101, 40);
            label8.TabIndex = 82;
            label8.Text = "Giá sản phẩm\r\n(nếu có)\r\n";
            label8.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            label7.Anchor = AnchorStyles.None;
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            label7.Location = new Point(893, 91);
            label7.Name = "label7";
            label7.Size = new Size(77, 40);
            label7.TabIndex = 80;
            label7.Text = "Lợi nhuận\r\n(nếu có)\r\n";
            label7.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // button3
            // 
            button3.Anchor = AnchorStyles.None;
            button3.BackColor = Color.Blue;
            button3.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            button3.ForeColor = Color.White;
            button3.Location = new Point(1017, 145);
            button3.Margin = new Padding(3, 2, 3, 2);
            button3.Name = "button3";
            button3.Size = new Size(106, 36);
            button3.TabIndex = 88;
            button3.Text = "Xác nhận";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click_1;
            // 
            // button6
            // 
            button6.Anchor = AnchorStyles.None;
            button6.BackColor = Color.FromArgb(0, 192, 0);
            button6.Font = new Font("Segoe UI Semibold", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 163);
            button6.ForeColor = Color.Black;
            button6.Location = new Point(1017, 104);
            button6.Margin = new Padding(3, 2, 3, 2);
            button6.Name = "button6";
            button6.Size = new Size(106, 36);
            button6.TabIndex = 89;
            button6.Text = "Lưu";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Anchor = AnchorStyles.Bottom;
            button7.BackColor = Color.Black;
            button7.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 163);
            button7.ForeColor = Color.White;
            button7.Location = new Point(1006, 680);
            button7.Margin = new Padding(3, 2, 3, 2);
            button7.Name = "button7";
            button7.Size = new Size(106, 37);
            button7.TabIndex = 91;
            button7.Text = "Tiếp tục";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click_1;
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(1209, 497);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button3);
            Controls.Add(label8);
            Controls.Add(Profit);
            Controls.Add(label7);
            Controls.Add(Revenue);
            Controls.Add(label6);
            Controls.Add(Quantity);
            Controls.Add(Price);
            Controls.Add(label4);
            Controls.Add(Time);
            Controls.Add(label3);
            Controls.Add(Cate);
            Controls.Add(label2);
            Controls.Add(button1);
            Controls.Add(button2);
            Controls.Add(dataGridView1);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(ID);
            Controls.Add(label1);
            Name = "Form2";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Form1";
            Load += Form2_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Label label1;
        private Label ID;
        private Button button4;
        private Button button5;
        private DataGridView dataGridView1;
        private Button button2;
        private Button button1;
        private Label label2;
        private CheckedListBox Cate;
        private Label label3;
        private CheckedListBox Time;
        private Label label4;
        private CheckedListBox Price;
        private CheckedListBox Quantity;
        private Label label6;
        private CheckedListBox Revenue;
        private CheckedListBox Profit;
        private Label label8;
        private Label label7;
        private Button button3;
        private Button button6;
        private Button button7;
    }
}
