using OfficeOpenXml;
using System.Data;
using System.Text;
using Microsoft.VisualBasic.FileIO;

namespace BI
{
    public partial class Form1 : Form
    {
        private DataTable processedData;
        private Form2 form2Instance;

        public Form1()
        {
            InitializeComponent();
            processedData = new DataTable();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        private void button7_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Excel Files (*.xls;*.xlsx)|*.xls;*.xlsx|CSV Files (*.csv)|*.csv";
                openFileDialog.Title = "Chọn tệp dữ liệu";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = openFileDialog.FileName;
                    labelFilePath.Text = $"Đã chọn tệp: {filePath}";

                    // Gọi hàm đọc file tương ứng
                    if (filePath.EndsWith(".csv"))
                    {
                        LoadCsvToDataGridView(filePath);
                    }
                    else if (filePath.EndsWith(".xls") || filePath.EndsWith(".xlsx"))
                    {
                        LoadExcelToDataGridView(filePath);
                    }
                }
            }
        }

        private void LoadDataFromFile(string filePath)
        {

        }

        private void LoadCsvToDataGridView(string filePath)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();

            using (TextFieldParser parser = new TextFieldParser(filePath))
            {
                parser.TextFieldType = FieldType.Delimited;
                parser.SetDelimiters(",");
                parser.HasFieldsEnclosedInQuotes = true;

                if (!parser.EndOfData)
                {
                    string[] headers = parser.ReadFields();
                    foreach (string header in headers)
                    {
                        dataGridView1.Columns.Add(header, header);
                    }
                }

                while (!parser.EndOfData)
                {
                    string[] fields = parser.ReadFields();
                    dataGridView1.Rows.Add(fields);
                }
            }
        }
        private void LoadExcelToDataGridView(string filePath)
        {
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;

            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();

            using (var package = new ExcelPackage(new FileInfo(filePath)))
            {
                var worksheet = package.Workbook.Worksheets[0];
                int colCount = worksheet.Dimension.End.Column;
                int rowCount = worksheet.Dimension.End.Row;

                for (int col = 1; col <= colCount; col++)
                {
                    string columnHeader = worksheet.Cells[1, col].Text;
                    dataGridView1.Columns.Add(columnHeader, columnHeader);
                }

                for (int row = 2; row <= rowCount; row++)
                {
                    var rowData = new List<string>();
                    for (int col = 1; col <= colCount; col++)
                    {
                        rowData.Add(worksheet.Cells[row, col].Text);
                    }
                    dataGridView1.Rows.Add(rowData.ToArray());
                }
            }
        }

        private void labelFilePath_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e) // Nút "Làm sạch"
        {
            processedData.Clear(); // Xóa dữ liệu cũ trong processedData nếu có
            processedData.Columns.Clear();

            // Thêm các cột vào processedData
            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                processedData.Columns.Add(column.Name);
            }

            // Thêm dữ liệu từ dataGridView1 vào processedData
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (!row.IsNewRow)
                {
                    DataRow dataRow = processedData.NewRow();
                    for (int i = 0; i < row.Cells.Count; i++)
                    {
                        dataRow[i] = row.Cells[i].Value ?? DBNull.Value;
                    }
                    processedData.Rows.Add(dataRow);
                }
            }

            // Xóa các hàng trống, hàng có ô trống và hàng trùng lặp trong `processedData`
            HashSet<string> seenRows = new HashSet<string>();
            for (int i = processedData.Rows.Count - 1; i >= 0; i--)
            {
                var row = processedData.Rows[i];

                // Kiểm tra nếu hàng có bất kỳ ô nào trống
                bool hasEmptyCell = row.ItemArray.Any(cell => cell == DBNull.Value || string.IsNullOrWhiteSpace(cell?.ToString()));

                // Tạo chuỗi đại diện cho hàng để kiểm tra trùng lặp
                StringBuilder rowString = new StringBuilder();
                foreach (var cell in row.ItemArray)
                {
                    rowString.Append(cell?.ToString() ?? "");
                    rowString.Append("|");
                }

                // Xóa hàng nếu có ô trống hoặc trùng lặp
                if (hasEmptyCell || seenRows.Contains(rowString.ToString()))
                {
                    processedData.Rows.RemoveAt(i);
                }
                else
                {
                    seenRows.Add(rowString.ToString());
                }
            }

            // Chuẩn hóa dữ liệu (đưa về chữ thường)
            foreach (DataRow row in processedData.Rows)
            {
                for (int i = 0; i < processedData.Columns.Count; i++)
                {
                    var cellValue = row[i]?.ToString();
                    if (cellValue != null)
                    {
                        row[i] = cellValue.ToLower();
                    }
                }
            }

            // Cập nhật lại dataGridView1 để phản ánh thay đổi trong processedData
            dataGridView1.Rows.Clear();
            foreach (DataRow row in processedData.Rows)
            {
                dataGridView1.Rows.Add(row.ItemArray);
            }

            MessageBox.Show("Dữ liệu đã được làm sạch cơ bản!");
        }

        private void button6_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "CSV files (*.csv)|*.csv";
                saveFileDialog.Title = "Lưu dữ liệu thành file CSV";

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    using (StreamWriter writer = new StreamWriter(saveFileDialog.FileName))
                    {
                        // Ghi dòng tiêu đề (tên cột)
                        for (int i = 0; i < dataGridView1.Columns.Count; i++)
                        {
                            writer.Write($"\"{dataGridView1.Columns[i].HeaderText}\"");
                            if (i < dataGridView1.Columns.Count - 1)
                                writer.Write(",");
                        }
                        writer.WriteLine();

                        // Ghi dữ liệu từng hàng
                        foreach (DataGridViewRow row in dataGridView1.Rows)
                        {
                            if (!row.IsNewRow)
                            {
                                for (int i = 0; i < dataGridView1.Columns.Count; i++)
                                {
                                    // Thêm dấu ngoặc kép xung quanh nội dung ô
                                    var cellValue = row.Cells[i].Value?.ToString().Replace("\"", "\"\""); // Xử lý dấu ngoặc kép trong nội dung
                                    writer.Write($"\"{cellValue}\"");

                                    if (i < dataGridView1.Columns.Count - 1)
                                        writer.Write(",");
                                }
                                writer.WriteLine();
                            }
                        }
                    }
                    MessageBox.Show("Dữ liệu đã được lưu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SetupDataGridView();
        }
        private void SetupDataGridView()
        {
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.None;
            dataGridView1.ScrollBars = ScrollBars.Both;

            foreach (DataGridViewColumn column in dataGridView1.Columns)
            {
                column.Width = 150; // Điều chỉnh giá trị này theo nhu cầu
            }
            dataGridView1.RowTemplate.Height = 25;
            dataGridView1.ScrollBars = ScrollBars.Both; // Hiển thị cả thanh cuộn ngang và dọc
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.AllowUserToResizeColumns = false;
            dataGridView1.AllowUserToResizeRows = false;

        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (form2Instance == null || form2Instance.IsDisposed)
            {
                // Truyền dữ liệu sang Form2
                form2Instance = new Form2(processedData);
                form2Instance.FormClosed += (s, args) => this.Show(); // Hiển thị lại Form1 khi Form2 đóng
                this.Hide(); // Ẩn Form1
                form2Instance.Show(); // Hiển thị Form2
            }
            else
            {
                this.Hide();
                form2Instance.Show();
            }
        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Show();
            form2Instance.Hide();
        }
    }
}