﻿using System;
using System.Data;
using System.Globalization;
using System.Linq;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.ML;
using Microsoft.ML.Data;
using Microsoft.ML.Trainers;

namespace BI
{
    public partial class Form3 : Form
    {
        private ITransformer _trainedModel;
        private MLContext _mlContext;
        private DateTime _startDate;
        private List<IGrouping<DateTime, DataRow>> groupedData;


        public Form3(DataTable data)
        {
            InitializeComponent();
            dataGridView1.DataSource = data;
            _mlContext = new MLContext();
        }

        // Model input class
        public class ModelInput
        {
            public DateTime Time { get; set; }
            public float Price { get; set; }
            public float Quantity { get; set; }
            public float Profit { get; set; }
            public string Cate { get; set; } = string.Empty;
            public float Label { get; set; }

            // Các chỉ số kinh tế giả định
            public float Inflation { get; set; }
            public float ExchangeRate { get; set; }
            public float GDPGrowth { get; set; }
            public float InterestRate { get; set; }
            public int ConsumerTrend { get; set; }
            public int CompetitionIndex { get; set; }
            public float TaxRate { get; set; }
            public float MarketingExpense { get; set; }
            public int InnovationIndex { get; set; }
        }

        // Model output class
        public class ModelOutput
        {
            [ColumnName("Score")]
            public float PredictedRevenue { get; set; }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            DataTable data = dataGridView1.DataSource as DataTable;
            if (data != null)
            {
                NormalizeDataTable(data);
                // Đảm bảo _startDate được xác định ngay sau khi normalize
                _startDate = data.AsEnumerable()
                                 .Min(row => row.Field<DateTime?>("Time") ?? DateTime.MaxValue);
            }

            // Gán giá trị mặc định cho DateTimePicker
            dateTimePicker1.Value = _startDate;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // Chuyển về Form1
            Form1 form1 = new Form1();
            form1.Show();
            this.Hide();
        }
        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private DataTable EnsureColumnsExist(DataTable data)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));

            // Danh sách các cột yêu cầu
            string[] requiredColumns = { "Price", "Quantity", "Profit", "Cate", "Revenue", "Time" };

            // Kiểm tra từng cột
            foreach (var col in requiredColumns)
            {
                if (!data.Columns.Contains(col))
                {
                    // Thêm cột với kiểu dữ liệu và giá trị mặc định
                    if (col == "Cate")
                        data.Columns.Add(col, typeof(string));
                    else if (col == "Time")
                        data.Columns.Add(col, typeof(DateTime));
                    else
                        data.Columns.Add(col, typeof(float));
                }
            }

            // Điền giá trị mặc định cho các hàng
            foreach (DataRow row in data.Rows)
            {
                if (string.IsNullOrEmpty(row["Price"]?.ToString())) row["Price"] = 0f;
                if (string.IsNullOrEmpty(row["Quantity"]?.ToString())) row["Quantity"] = 0f;
                if (string.IsNullOrEmpty(row["Profit"]?.ToString())) row["Profit"] = 0f;
                if (string.IsNullOrEmpty(row["Cate"]?.ToString())) row["Cate"] = string.Empty;
            }

            return data;
        }

        private DateTime ParseToDateTime(string input)
        {
            string[] formats = { "MM/dd/yyyy", "yyyy-MM-dd", "yyyy/MM/dd", "dd-MM-yyyy", "dd/MM/yyyy", "MMM dd, yyyy", "yyyy" };

            if (DateTime.TryParseExact(input, formats,
                                       CultureInfo.InvariantCulture,
                                       DateTimeStyles.None,
                                       out DateTime parsedDate))
            {
                // Nếu chỉ có "yyyy", mặc định là ngày 1 tháng 1 của năm đó
                if (input.Length == 4) 
                {
                    parsedDate = new DateTime(parsedDate.Year, 1, 1);
                }

                return parsedDate;
            }

            throw new FormatException($"Chuỗi '{input}' không phải là định dạng ngày hợp lệ.");
        }

        private bool IsValidDateTime(string input)
        {
            // Các định dạng ngày cần hỗ trợ
            string[] formats = { "MM/dd/yyyy", "yyyy-MM-dd", "yyyy/MM/dd", "dd-MM-yyyy", "dd/MM/yyyy", "MMM dd, yyyy", "yyyy" };

            // Thử chuyển đổi chuỗi sang DateTime
            return DateTime.TryParseExact(input, formats,
                                          CultureInfo.InvariantCulture,
                                          DateTimeStyles.None,
                                          out _);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            // Lấy dữ liệu từ DataGridView
            DataTable data = dataGridView1.DataSource as DataTable;
            if (data == null || data.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu để huấn luyện mô hình.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            if (_trainedModel == null && !TrainModel(data))
            {
                MessageBox.Show("Huấn luyện mô hình thất bại.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
        }
        private bool TrainModel(DataTable data)
        {
            try
            {
                // Chuẩn hóa và kiểm tra các cột cần thiết
                DataTable normalizedData = EnsureColumnsExist(data);

                // Kiểm tra lại dữ liệu sau khi bổ sung cột
                if (normalizedData == null || normalizedData.Rows.Count == 0)
                {
                    MessageBox.Show("Dữ liệu không hợp lệ để huấn luyện mô hình.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return false;
                }
                // Chuyển đổi DataTable thành danh sách ModelInput
                var dataInputs = normalizedData.AsEnumerable().Select(row => new ModelInput
                {
                    Price = Convert.ToSingle(row["Price"]),
                    Quantity = Convert.ToSingle(row["Quantity"]),
                    Profit = Convert.ToSingle(row["Profit"]),
                    Cate = row["Cate"].ToString(),
                    Label = Convert.ToSingle(row["Revenue"]),
                }).ToList();

                var dataView = _mlContext.Data.LoadFromEnumerable(dataInputs);

                // Chia dữ liệu thành tập huấn luyện và kiểm thử
                var splitData = _mlContext.Data.TrainTestSplit(dataView, testFraction: 0.2);

                // Tạo pipeline huấn luyện
                var pipeline = _mlContext.Transforms.Categorical.OneHotEncoding("CateEncoded", "Cate")
                    .Append(_mlContext.Transforms.Concatenate("Features", "Price", "Quantity", "Profit", "CateEncoded"))
                    .Append(_mlContext.Regression.Trainers.FastTree(
                        labelColumnName: "Label",
                        featureColumnName: "Features",
                        numberOfLeaves: 30,
                        numberOfTrees: 150,
                        learningRate: 0.2f,
                        minimumExampleCountPerLeaf: 10));

                var stopwatch = new System.Diagnostics.Stopwatch();
                stopwatch.Start();

                // Huấn luyện mô hình
                _trainedModel = pipeline.Fit(splitData.TrainSet);

                // Đánh giá mô hình
                var testPredictions = _trainedModel.Transform(splitData.TestSet);
                var metrics = _mlContext.Regression.Evaluate(testPredictions, labelColumnName: "Label");

                stopwatch.Stop();
                MessageBox.Show($"Huấn luyện hoàn tất!\n" +
                                $"R2 Score: {metrics.RSquared:0.###}\n" +
                                $"Thời gian huấn luyện: {stopwatch.Elapsed.TotalSeconds:F2} giây",
                                "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                return true;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi trong quá trình huấn luyện: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            
        }
        private DataTable NormalizeDataTable(DataTable data)
        {
            if (data == null) throw new ArgumentNullException(nameof(data));

            // Đảm bảo các cột bắt buộc tồn tại
            string[] requiredColumns = { "Revenue", "Time", "Price", "Quantity", "Profit", "Cate"};
            foreach (string col in requiredColumns)
            {
                if (!data.Columns.Contains(col))
                {
                    Type columnType = col == "Time" ? typeof(DateTime) :
                                      col == "Cate" ? typeof(string) :
                                      typeof(float);
                    data.Columns.Add(col, columnType);
                }
            }

            foreach (DataRow row in data.Rows)
            {
                float averageRevenue = SafeConvertToFloat(row["Revenue"]);

                row["Revenue"] = SafeConvertToFloat(row["Revenue"]);
                row["Price"] = SafeConvertToFloat(row["Price"], defaultValue: 1f);
                row["Quantity"] = SafeConvertToFloat(row["Quantity"], defaultValue: 1f);
                row["Profit"] = SafeConvertToFloat(row["Profit"], defaultValue: 0f);
                row["Cate"] = string.IsNullOrEmpty(row["Cate"]?.ToString()) ? "Unknown" : row["Cate"];

                // Xử lý Time
                row["Time"] = DateTime.TryParse(row["Time"]?.ToString(), out DateTime timeVal)
                                ? timeVal : DBNull.Value;
            }

            // Loại bỏ hàng không hợp lệ
            data.Rows.Cast<DataRow>()
                .Where(row => row["Time"] == DBNull.Value)
                .ToList()
                .ForEach(row => data.Rows.Remove(row));

            return data;
        }

        private float SafeConvertToFloat(object value, float defaultValue = 0f)
        {
            if (value == null || !float.TryParse(value.ToString(), out float result))
            {
                return defaultValue;
            }
            return result;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (_trainedModel == null)
            {
                MessageBox.Show("Vui lòng huấn luyện mô hình trước!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Lấy dữ liệu hiện tại từ DataGridView
            var data = dataGridView1.DataSource as DataTable;
            if (data == null || data.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu để dự báo.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Nhóm dữ liệu theo cột Time
            this.groupedData = data.AsEnumerable()
                .Where(row => row["Time"] != DBNull.Value &&
                              (row["Time"] is DateTime || IsValidDateTime(row["Time"].ToString())))
                .GroupBy(row => row["Time"] is DateTime
                                    ? (DateTime)row["Time"]
                                    : ParseToDateTime(row["Time"].ToString()))
                .OrderBy(group => group.Key)
                .ToList();

            if (!this.groupedData.Any())
            {
                MessageBox.Show("Không tìm thấy dữ liệu ngày hợp lệ trong cột Time.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Chuẩn bị đầu vào dự báo cho dữ liệu hiện tại
            var predictionInputs = groupedData.Select(group => new ModelInput
            {
                Price = group.Average(row => SafeConvertToFloat(row["Price"])),
                Quantity = group.Average(row => SafeConvertToFloat(row["Quantity"])),
                Profit = group.Average(row => SafeConvertToFloat(row["Profit"])),
                Cate = group.First()["Cate"].ToString(),
            }).ToList();

            // Thực hiện dự báo cho dữ liệu hiện tại bằng Transform thay vì PredictionEngine
            var dataView = _mlContext.Data.LoadFromEnumerable(predictionInputs);
            var transformedData = _trainedModel.Transform(dataView);

            var currentPredictions = _mlContext.Data.CreateEnumerable<ModelOutput>(transformedData, reuseRowObject: false)
                                                     .Select(output => output.PredictedRevenue)
                                                     .ToList();

            // Dự báo tương lai dựa trên ngày cuối cùng trong dữ liệu hiện tại
            var lastDate = groupedData.Max(group => group.Key);
            var selectedEndDate = dateTimePicker1.Value; // Lấy ngày kết thúc từ DateTimePicker

            // Tạo dữ liệu dự báo tương lai từ ngày cuối cùng đến ngày được chọn
            var futureData = GenerateFutureData(lastDate.AddDays(1), selectedEndDate, "month");

            // Dự báo cho dữ liệu tương lai
            var futureDataView = _mlContext.Data.LoadFromEnumerable(futureData);
            var futureTransformedData = _trainedModel.Transform(futureDataView);

            var futurePredictions = _mlContext.Data.CreateEnumerable<ModelOutput>(futureTransformedData, reuseRowObject: false)
                                                   .Select(output => output.PredictedRevenue)
                                                   .ToList();

            var futureDates = futureData.Select(input => input.Time).ToList();

            // Kết hợp dữ liệu hiện tại và tương lai
            var allDates = groupedData.Select(group => group.Key).Concat(futureDates).ToList();
            var allRevenues = currentPredictions.Concat(futurePredictions).ToList();

            // Hiển thị kết quả trên biểu đồ
            ShowPredictionChart(allDates, allRevenues);
        }

        private void PerformPrediction(List<DateTime> predictionDates, DateTime startDate, DateTime endDate, string intervalType)
        {
            var data = dataGridView1.DataSource as DataTable;
            if (data == null || data.Rows.Count == 0)
            {
                MessageBox.Show("Không có dữ liệu để dự báo.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            // Lấy dữ liệu đầu vào từ DataTable
            var inputs = data.AsEnumerable().Select(row => new ModelInput
            {
                Price = SafeConvertToFloat(row["Price"]),
                Quantity = SafeConvertToFloat(row["Quantity"]),
                Profit = SafeConvertToFloat(row["Profit"]),
                Cate = row["Cate"].ToString()
            }).ToList();

            // Tạo dữ liệu tương lai
            var futureData = GenerateFutureData(startDate, endDate, intervalType);

            // Tạo prediction engine
            var predictionEngine = _mlContext.Model.CreatePredictionEngine<ModelInput, ModelOutput>(_trainedModel);

            // Thực hiện dự báo và ghi log từng giá trị
            var predictions = new List<float>();
            foreach (var input in futureData)
            {
                var result = predictionEngine.Predict(input);
                Console.WriteLine($"Date: {input.Time}, Predicted Revenue: {result.PredictedRevenue}"); // Ghi log
                predictions.Add(result.PredictedRevenue);
            }

            // Gọi hàm hiển thị biểu đồ
            ShowPredictionChart(predictionDates, predictions);
        }

        private List<ModelInput> GenerateFutureData(DateTime startDate, DateTime endDate, string intervalType)
        {
            var futureData = new List<ModelInput>();
            DateTime currentDate = startDate;

            // Lấy giá trị cuối cùng trong dữ liệu hiện tại làm điểm khởi đầu
            var lastGroup = groupedData.Last();
            var lastInput = new ModelInput
            {
                Price = lastGroup.Average(row => SafeConvertToFloat(row["Price"])),
                Quantity = lastGroup.Average(row => SafeConvertToFloat(row["Quantity"])),
                Profit = lastGroup.Average(row => SafeConvertToFloat(row["Profit"])),
                Cate = lastGroup.First()["Cate"].ToString()
            };

            // Giả định các yếu tố vĩ mô hỗ trợ tăng trưởng
            float inflationRate = 0.05f;      // 5% mỗi năm
            float gdpGrowthRate = 0.04f;     // 4% mỗi năm
            float marketingEffect = 0.02f;  // 2% tăng trưởng từ chi phí marketing
            float innovationEffect = 0.03f; // 3% tăng trưởng từ đổi mới

            // Các giá trị sẽ được cập nhật hàng năm
            int currentYear = currentDate.Year;
            float inflationAdjustment = 1.0f;
            float gdpAdjustment = 1.0f;

            // Tạo dữ liệu tương lai
            while (currentDate <= endDate)
            {
                // Kiểm tra nếu bước sang một năm mới
                if (currentDate.Year > currentYear)
                {
                    currentYear = currentDate.Year;

                    // Cập nhật các yếu tố vĩ mô hàng năm
                    inflationAdjustment *= (1 + inflationRate);
                    gdpAdjustment *= (1 + gdpGrowthRate);
                }

                // Tạo dữ liệu mới cho ngày hiện tại
                futureData.Add(new ModelInput
                {
                    Time = currentDate,
                    Price = lastInput.Price * inflationAdjustment * 1.1f,       // Ví dụ
                    Quantity = lastInput.Quantity * inflationAdjustment * 1.05f,
                    Profit = lastInput.Profit * inflationAdjustment * 1.15f,
                    Cate = lastInput.Cate,
                    Inflation = inflationRate * 100,
                    ExchangeRate = 1.02f,
                    GDPGrowth = gdpGrowthRate * 100,
                    InterestRate = 6.5f,
                    ConsumerTrend = 7 + (int)(gdpAdjustment * 2),
                    CompetitionIndex = 5,
                    TaxRate = 20.0f,
                    MarketingExpense = 10000f,
                    InnovationIndex = 8 + (int)(innovationEffect * 10)
                });

                // Cập nhật ngày
                currentDate = intervalType.ToLower() == "month"
                    ? currentDate.AddMonths(1)
                    : currentDate.AddDays(1);
            }

            return futureData;
        }

        private void ShowPredictionChart(List<DateTime> dates, List<float> revenues)
        {
            // Xóa các Series cũ
            chart1.Series.Clear();

            // Cấu hình ChartArea và bật cuộn ngang
            if (chart1.ChartAreas.Count == 0)
            {
                chart1.ChartAreas.Add(new ChartArea("Default"));
            }
            var chartArea = chart1.ChartAreas[0];
            chartArea.AxisX.ScrollBar.Enabled = true;
            chartArea.AxisX.ScrollBar.Size = 15;
            chartArea.AxisX.ScrollBar.ButtonStyle = ScrollBarButtonStyles.SmallScroll;
            chartArea.AxisX.ScaleView.Zoomable = true;
            chartArea.AxisX.ScaleView.Size = 12; // Hiển thị tối đa 12 điểm trên biểu đồ
            chartArea.AxisX.ScaleView.MinSize = 5; // Thu nhỏ tối thiểu đến 5 điểm
            chartArea.AxisX.Interval = 1; // Hiển thị nhãn từng mốc
            chartArea.AxisX.LabelStyle.Format = "MM-yyyy"; // Định dạng trục X 
            chartArea.AxisX.MajorGrid.Enabled = false; // Tắt lưới trục X
            chartArea.AxisY.MajorGrid.Enabled = true; // Bật lưới trục Y để dễ đọc giá trị

            // Thêm Series dữ liệu thực tế
            var actualSeries = new Series("Dữ liệu thực tế")
            {
                ChartType = SeriesChartType.Point,
                MarkerStyle = MarkerStyle.Circle,
                MarkerSize = 10,
                Color = System.Drawing.Color.Blue
            };

            // Thêm Series dữ liệu dự báo
            var predictionSeries = new Series("Doanh thu dự báo")
            {
                ChartType = SeriesChartType.Line,
                BorderWidth = 3,
                Color = System.Drawing.Color.Red,
                MarkerStyle = MarkerStyle.Diamond,
                MarkerSize = 8
            };

            // Thêm dữ liệu dự báo vào Series
            for (int i = 0; i < dates.Count; i++)
            {
                predictionSeries.Points.AddXY(dates[i], revenues[i]);
            }

            // Thêm các Series vào biểu đồ
            chart1.Series.Add(actualSeries);
            chart1.Series.Add(predictionSeries);
            chart1.ChartAreas[0].AxisX.IntervalType = DateTimeIntervalType.Months;
            chart1.ChartAreas[0].AxisX.Interval = 1;
            chart1.ChartAreas[0].RecalculateAxesScale();
        }

        private void chart1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click_1(object sender, EventArgs e)
        {

        }
        private void Form3_Load_1(object sender, EventArgs e)
        {

        }
    }
}